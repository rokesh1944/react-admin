
import { Search, Bell, User, Printer } from 'lucide-react';

export function InvoiceView() {
  const invoiceData = {
    invoiceNumber: "62786457345",
    company: {
      name: "Shree Clothings",
      dateOfDispatch: "07/12/2023",
      contactNumber: "+91 99999 88888",
      emailId: "sutharanisect@gmail.com",
      address: "XYZ, ABCDE, digital, Thoothukudi, Tamil Nadu, India, 600 002"
    },
    customer: {
      name: "Ramesh",
      dateOfOrder: "07/12/2023",
      contactNumber: "+91 99999 88888, +91 99999 89898",
      emailId: "ramesh@gmail.com",
      billingAddress: "XYZ, ABCDE, Tambaram, Chennai, Tamil Nadu, India, 600 002"
    },
    products: [
      { sl: "01", code: "245", category: "Men", subCategory: "T-shirt", name: "Printed", size: "M", color: "#8B0000", quantity: 1, price: "Rs. 100" },
      { sl: "02", code: "103", category: "Men", subCategory: "Shirt", name: "Formals", size: "34", color: "#1E40AF", quantity: 1, price: "Rs. 100" }
    ]
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Invoice */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="text-sm text-gray-600">
            Invoice number : {invoiceData.invoiceNumber}
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
            <Printer className="h-4 w-4" />
            Print
          </button>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-8">
          {/* Company Details */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Company Name</h4>
            <div className="space-y-1 text-sm">
              <div className="flex">
                <span className="w-32 text-gray-600">Date of Dispatch</span>
                <span className="text-gray-900">{invoiceData.company.dateOfDispatch}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-gray-600">Contact Number</span>
                <span className="text-gray-900">{invoiceData.company.contactNumber}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-gray-600">Email ID</span>
                <span className="text-gray-900">{invoiceData.company.emailId}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-gray-600">Company Address</span>
                <span className="text-gray-900">{invoiceData.company.address}</span>
              </div>
            </div>
          </div>

          {/* Customer Details */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Customer Name</h4>
            <div className="space-y-1 text-sm">
              <div className="flex">
                <span className="w-32 text-gray-600">Date of Order</span>
                <span className="text-gray-900">{invoiceData.customer.dateOfOrder}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-gray-600">Contact Number</span>
                <span className="text-gray-900">{invoiceData.customer.contactNumber}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-gray-600">Email ID</span>
                <span className="text-gray-900">{invoiceData.customer.emailId}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-gray-600">Billing Address</span>
                <span className="text-gray-900">{invoiceData.customer.billingAddress}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Table */}
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Product Details</h4>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sl. no.</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product Code</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sub Category</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product Name</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Colour</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {invoiceData.products.map((product) => (
                  <tr key={product.sl}>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.sl}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.code}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.category}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.subCategory}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.size}</td>
                    <td className="px-4 py-3">
                      <div className="w-6 h-6 rounded" style={{ backgroundColor: product.color }}></div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.quantity}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.price}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Invoice Summary */}
          <div className="mt-6 flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal :</span>
                <span className="text-gray-900">Rs. 200</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Gst (10%) :</span>
                <span className="text-gray-900">Rs. 20</span>
              </div>
              <div className="border-t border-gray-200 pt-2">
                <div className="flex justify-between text-sm font-medium">
                  <span className="text-gray-900">Total :</span>
                  <span className="text-gray-900">Rs. 220</span>
                </div>
              </div>
            </div>
          </div>

          {/* Save Invoice Button */}
          <div className="mt-6 flex justify-end">
            <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
              Save Invoice
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
