
import { Search, Bell, User, Printer } from 'lucide-react';

interface OrderDetailsProps {
  orderId?: string;
  onBack?: () => void;
}

export function OrderDetails({ orderId = "01", onBack }: OrderDetailsProps) {
  const orderData = {
    customerName: "Ramesh",
    dateOfOrder: "07/12/2023",
    contactNumber: "+91 99999 88888, +91 99999 89898",
    emailId: "ramesh@gmail.com",
    billingAddress: "XYZ, ABCDE, Tambaram, Chennai, Tamil Nadu, India, 600 002",
    products: [
      { sl: "01", code: "245", category: "Men", subCategory: "T-shirt", name: "Printed", size: "M", color: "#8B0000", quantity: 1, price: "Rs. 100" },
      { sl: "02", code: "103", category: "Men", subCategory: "Shirt", name: "Formals", size: "34", color: "#1E40AF", quantity: 1, price: "Rs. 100" }
    ]
  };

  const subtotal = 200;
  const gst = 20;
  const total = 220;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Order Details */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="grid grid-cols-2 gap-8">
          {/* Customer Details */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Details</h3>
            <div className="space-y-3">
              <div className="flex">
                <span className="w-32 text-sm text-gray-600">Customer Name</span>
                <span className="text-sm text-gray-900">{orderData.customerName}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-sm text-gray-600">Date of Order</span>
                <span className="text-sm text-gray-900">{orderData.dateOfOrder}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-sm text-gray-600">Contact Number</span>
                <span className="text-sm text-gray-900">{orderData.contactNumber}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-sm text-gray-600">Email ID</span>
                <span className="text-sm text-gray-900">{orderData.emailId}</span>
              </div>
              <div className="flex">
                <span className="w-32 text-sm text-gray-600">Billing Address</span>
                <span className="text-sm text-gray-900">{orderData.billingAddress}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Product Details</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sl. no.</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product Code</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sub Category</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product Name</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Colour</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {orderData.products.map((product) => (
                  <tr key={product.sl}>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.sl}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.code}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.category}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.subCategory}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.size}</td>
                    <td className="px-4 py-3">
                      <div className="w-6 h-6 rounded" style={{ backgroundColor: product.color }}></div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.quantity}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{product.price}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Order Summary */}
          <div className="mt-6 flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal :</span>
                <span className="text-gray-900">Rs. {subtotal}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Gst (10%) :</span>
                <span className="text-gray-900">Rs. {gst}</span>
              </div>
              <div className="border-t border-gray-200 pt-2">
                <div className="flex justify-between text-sm font-medium">
                  <span className="text-gray-900">Total :</span>
                  <span className="text-gray-900">Rs. {total}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Generate Invoice Button */}
          <div className="mt-6 flex justify-end">
            <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
              Generate Invoice
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
