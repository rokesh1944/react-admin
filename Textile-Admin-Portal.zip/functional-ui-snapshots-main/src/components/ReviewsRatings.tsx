
import { useState } from 'react';
import { Search, Bell, User, Star } from 'lucide-react';

const reviewsData = [
  {
    id: 1,
    name: 'Ramesh',
    date: 'December 10, 2023',
    timeAgo: '1 day ago',
    rating: 4,
    title: 'The Products I purchased was too good.',
    review: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer pellentesque id dui eget venenatis. In hac habitasse platea dictumst. Pellentesque lacinia placerat nisi non sagittis orci porttitor a. Vivamus non nunc augue ultrices tempus vestibulum vel vel sem.'
  },
  {
    id: 2,
    name: 'Suresh',
    date: 'December 09, 2023',
    timeAgo: '2 day ago',
    rating: 4,
    title: 'The Products I purchased was too good.',
    review: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer pellentesque id dui eget venenatis. In hac habitasse platea dictumst. Pellentesque lacinia placerat nisi non sagittis orci porttitor a. Vivamus non nunc augue ultrices tempus vestibulum vel vel sem.'
  }
];

export function ReviewsRatings() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredReviews = reviewsData.filter(review =>
    review.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    review.review.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="space-y-6">
        {filteredReviews.map((review) => (
          <div key={review.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-semibold text-gray-900 text-lg">{review.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-sm text-gray-600">{review.date}</span>
                  <span className="text-sm text-gray-400">({review.rating}/5)</span>
                </div>
                <span className="text-xs text-gray-500">{review.timeAgo}</span>
              </div>
              <div className="flex items-center gap-1">
                {renderStars(review.rating)}
              </div>
            </div>

            <h4 className="font-medium text-gray-900 mb-2">{review.title}</h4>
            <p className="text-gray-600 text-sm leading-relaxed mb-4">{review.review}</p>

            <div className="flex justify-end gap-3">
              <button className="px-4 py-2 text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors">
                Reject
              </button>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                Approve
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
