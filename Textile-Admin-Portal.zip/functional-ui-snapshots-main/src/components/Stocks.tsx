
import { useState } from 'react';
import { Search, Bell, User, Filter, Plus, ChevronDown } from 'lucide-react';
import { StockForm } from './stocks/StockForm';

const stocksData = [
  { sl: '01', code: '001', category: 'Men', subCategory: 'T-shirt', product: 'Men Printed Polo...', updatedOn: '07/12/2023', availableQty: 80 },
  { sl: '02', code: '002', category: 'Men', subCategory: 'T-shirt', product: 'Men Printed Rou...', updatedOn: '07/12/2023', availableQty: 100 },
  { sl: '03', code: '003', category: 'Men', subCategory: 'Shirt', product: 'Formal Shirt', updatedOn: '07/12/2023', availableQty: 200 },
  { sl: '04', code: '004', category: 'Men', subCategory: 'Shirt', product: 'Casual Shirt', updatedOn: '07/12/2023', availableQty: 250 },
  { sl: '05', code: '005', category: 'Men', subCategory: 'Pant', product: 'Black Track Pants', updatedOn: '07/12/2023', availableQty: 300 },
  { sl: '06', code: '006', category: 'Women', subCategory: 'Saree', product: 'Cotton Blend Saree', updatedOn: '07/12/2023', availableQty: 350 },
  { sl: '07', code: '007', category: 'women', subCategory: 'Kurth', product: 'Anarkali Kurta', updatedOn: '07/12/2023', availableQty: 400 },
  { sl: '08', code: '008', category: 'Women', subCategory: 'Shall', product: 'Chiffon Shall', updatedOn: '07/12/2023', availableQty: 450 },
  { sl: '09', code: '009', category: 'Kids', subCategory: 'T-shirt', product: 'Pure Cotton T Shirt', updatedOn: '07/12/2023', availableQty: 500 },
  { sl: '10', code: '010', category: 'Kids', subCategory: 'Shorts', product: 'Shorts', updatedOn: '07/12/2023', availableQty: 550 },
  { sl: '11', code: '011', category: 'Kids', subCategory: 'vest', product: 'Vest For Baby', updatedOn: '07/12/2023', availableQty: 600 },
  { sl: '12', code: '012', category: 'Women', subCategory: 'Blouse', product: 'Round Neck Blouse', updatedOn: '07/12/2023', availableQty: 650 },
  { sl: '13', code: '013', category: 'Accessories', subCategory: 'Belt', product: 'Belts', updatedOn: '07/12/2023', availableQty: 700 },
  { sl: '14', code: '014', category: 'Accessories', subCategory: 'kerchief', product: 'Hand Kerchief', updatedOn: '07/12/2023', availableQty: 750 },
  { sl: '15', code: '015', category: 'Kids', subCategory: 'T-shirt', product: 'Printed T-shirts', updatedOn: '07/12/2023', availableQty: 800 }
];

export function Stocks() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showForm, setShowForm] = useState(false);

  const filteredStocks = stocksData.filter(stock => {
    const matchesSearch = stock.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         stock.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         stock.code.includes(searchTerm);
    const matchesCategory = selectedCategory === 'All' || stock.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  if (showForm) {
    return <StockForm onClose={() => setShowForm(false)} />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stocks Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Stocks</h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-600">Filters</span>
            </div>
            <div className="relative">
              <select 
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="appearance-none border border-gray-300 rounded px-3 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="All">Category : All</option>
                <option value="Men">Men</option>
                <option value="Women">Women</option>
                <option value="Kids">Kids</option>
                <option value="Accessories">Accessories</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
            <button 
              onClick={() => setShowForm(true)}
              className="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2 hover:bg-green-700 transition-colors"
            >
              <Plus className="h-4 w-4" />
              New Product
            </button>
          </div>
        </div>

        {/* Stocks Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sl. no.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product code</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sub Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Updated On</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Available Qty.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredStocks.map((stock) => (
                <tr key={stock.sl} className="hover:bg-gray-50">
                  <td className="px-4 py-4 text-sm text-gray-900">{stock.sl}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{stock.code}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{stock.category}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{stock.subCategory}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{stock.product}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{stock.updatedOn}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{stock.availableQty}</td>
                  <td className="px-4 py-4">
                    <button className="text-sm text-white bg-green-600 px-3 py-1 rounded hover:bg-green-700 transition-colors">
                      Add More
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-2 mt-6">
          <button className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center text-sm font-medium">1</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">2</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">3</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">4</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">5</button>
          <span className="text-gray-400 px-2">...</span>
        </div>
      </div>
    </div>
  );
}
