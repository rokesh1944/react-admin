
import { Package, ShoppingCart, Truck, DollarSign } from 'lucide-react';

interface StatsCardProps {
  title: string;
  subtitle: string;
  icon: string;
  bgColor: string;
  iconColor: string;
}

export function StatsCard({ title, subtitle, icon, bgColor, iconColor }: StatsCardProps) {
  const getIcon = () => {
    switch (icon) {
      case 'package':
        return <Package className={`h-8 w-8 ${iconColor}`} />;
      case 'shopping-cart':
        return <ShoppingCart className={`h-8 w-8 ${iconColor}`} />;
      case 'truck':
        return <Truck className={`h-8 w-8 ${iconColor}`} />;
      case 'dollar-sign':
        return <DollarSign className={`h-8 w-8 ${iconColor}`} />;
      default:
        return <Package className={`h-8 w-8 ${iconColor}`} />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-3xl font-bold text-gray-900">{title}</p>
          <p className="text-sm text-gray-600 mt-1">{subtitle}</p>
        </div>
        <div className={`p-3 rounded-lg ${bgColor}`}>
          {getIcon()}
        </div>
      </div>
    </div>
  );
}
