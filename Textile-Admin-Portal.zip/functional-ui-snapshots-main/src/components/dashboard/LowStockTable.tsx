
const lowStockItems = [
  { id: '01', code: '26757', product: 'Shirts', quantity: 10 },
  { id: '02', code: '26757', product: 'Leggins', quantity: 16 },
  { id: '03', code: '26757', product: 'T-shirt', quantity: 12 },
  { id: '04', code: '26767', product: 'Hand kerchief', quantity: 13 },
  { id: '05', code: '26767', product: 'Nightie', quantity: 19 },
];

export function LowStockTable() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Low Stock</h3>
        <button className="text-sm text-green-600 hover:text-green-700">View All</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sl. no.</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Code</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {lowStockItems.map((item) => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-900">{item.id}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.code}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{item.product}</td>
                <td className="px-4 py-3 text-sm font-medium text-red-600">{item.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
