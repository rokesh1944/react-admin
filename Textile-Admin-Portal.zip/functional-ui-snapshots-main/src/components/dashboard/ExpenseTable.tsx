
const expenses = [
  { id: '01', date: '16/11/2023', category: 'Plumbing', subcategory: 'Tapes, Pipes, Joints', amount: 'Rs.1,000', status: 'Paid' },
  { id: '02', date: '16/11/2023', category: 'Painting', subcategory: 'Paint brush', amount: 'Rs.450', status: 'Unpaid' },
  { id: '03', date: '12/11/2023', category: 'Carpentry', subcategory: 'Wood', amount: 'Rs.6,000', status: 'Paid' },
  { id: '04', date: '11/11/2023', category: 'Transport', subcategory: 'Diesel', amount: 'Rs.600', status: 'Unpaid' },
  { id: '05', date: '11/11/2023', category: 'Electrical', subcategory: 'wires', amount: 'Rs.1,100', status: 'Paid' },
];

export function ExpenseTable() {
  const getStatusColor = (status: string) => {
    return status === 'Paid' 
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Expense</h3>
        <button className="text-sm text-green-600 hover:text-green-700">View All</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sl. no.</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sub Category</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {expenses.map((expense) => (
              <tr key={expense.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-900">{expense.id}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{expense.date}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{expense.category}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{expense.subcategory}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{expense.amount}</td>
                <td className="px-4 py-3">
                  <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(expense.status)}`}>
                    {expense.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
