
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { name: 'Mens', value: 30, color: '#10B981' },
  { name: 'Womens', value: 25, color: '#059669' },
  { name: 'Kids', value: 20, color: '#34D399' },
  { name: 'Others', value: 25, color: '#6EE7B7' },
];

export function RevenueChart() {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Revenue</h3>
        <select className="text-sm border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-green-500">
          <option>Today</option>
          <option>Week</option>
          <option>Month</option>
        </select>
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 space-y-2">
        {data.map((item, index) => (
          <div key={index} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded`} style={{ backgroundColor: item.color }}></div>
              <span className="text-gray-600">{item.name}</span>
            </div>
            <span className="font-medium">Rs.{item.value * 1000}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
