
const orders = [
  { id: '01', name: 'Praveen', location: 'Coimbatore', mobile: '6767 66291', products: 'Shirt', code: '26757', quantity: 16 },
  { id: '02', name: 'Gokul', location: 'Nagercoil', mobile: '98134 67238', products: 'Tops', code: '26757', quantity: 15 },
  { id: '03', name: 'Priya', location: 'Tirunelveli', mobile: '74340 46749', products: 'Tops', code: '26757', quantity: 12 },
  { id: '04', name: 'Amjad', location: 'Chennai', mobile: '43101 73976', products: 'Saree', code: '26767', quantity: 13 },
  { id: '05', name: 'Anitha', location: 'Madurai', mobile: '53837 83741', products: 'Kurthi', code: '26767', quantity: 19 },
];

export function OrdersTable() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Orders</h3>
        <button className="text-sm text-green-600 hover:text-green-700">View All</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sl. no.</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mobile</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Products</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Code</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-900">{order.id}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{order.name}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{order.location}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{order.mobile}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{order.products}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{order.code}</td>
                <td className="px-4 py-3 text-sm text-gray-900 font-medium">{order.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
