
import { useState } from 'react';
import { Search, Bell, User, Filter, Plus, Eye, Edit } from 'lucide-react';
import { ProductForm } from './products/ProductForm';

const products = [
  { id: '01', date: '16/11/2023', code: '100', category: 'Men', subcategory: 'T-Shirt', product: 'Men Printed Polo', price: 'Rs.100', gst: '10%', status: 'Active' },
  { id: '02', date: '16/11/2023', code: '101', category: 'Men', subcategory: 'T-Shirt', product: 'Men Printed Polo', price: 'Rs.100', gst: '10%', status: 'Active' },
  { id: '03', date: '05/11/2023', code: '102', category: 'Men', subcategory: 'Shirt', product: 'Formal Shirt', price: 'Rs.100', gst: '10%', status: 'Active' },
  { id: '04', date: '04/11/2023', code: '103', category: 'Men', subcategory: 'Shirt', product: 'Casual Shirt', price: 'Rs.100', gst: '10%', status: 'Active' },
  { id: '05', date: '05/11/2023', code: '104', category: 'Men', subcategory: 'Pant', product: 'Black Track Pants', price: 'Rs.100', gst: '10%', status: 'Active' },
  { id: '06', date: '04/11/2023', code: '105', category: 'Women', subcategory: 'Saree', product: 'Cotton Saree Gyrus', price: 'Rs.150', gst: '10%', status: 'Inactive' },
  { id: '07', date: '04/11/2023', code: '106', category: 'Women', subcategory: 'Kurth', product: 'Ajrakh Kurth', price: 'Rs.100', gst: '10%', status: 'Inactive' },
  { id: '08', date: '28/10/2023', code: '107', category: 'Women', subcategory: 'Skirt', product: 'Dohter Skirt', price: 'Rs.100', gst: '10%', status: 'Out of Stock' },
  { id: '09', date: '28/10/2023', code: '108', category: 'Women', subcategory: 'Top', product: 'Pure Cotton Top Shirt', price: 'Rs.150', gst: '10%', status: 'Out of Stock' },
  { id: '10', date: '26/10/2023', code: '109', category: 'Kids', subcategory: 'Shorts', product: 'Shorts', price: 'Rs.100', gst: '10%', status: 'Out of Stock' },
];

export function UploadProducts() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('Active');

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.code.includes(searchTerm);
    const matchesStatus = selectedStatus === 'All' || product.status === selectedStatus;
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Inactive':
        return 'bg-red-100 text-red-800';
      case 'Out of Stock':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (showForm) {
    return <ProductForm onClose={() => setShowForm(false)} />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Product Details</h2>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            <button 
              onClick={() => setShowForm(true)}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              New Product
            </button>
          </div>
        </div>

        {/* Status Tabs */}
        <div className="flex items-center gap-8 mb-6 border-b border-gray-200">
          <button 
            onClick={() => setSelectedStatus('Active')}
            className={`pb-3 px-1 border-b-2 transition-colors font-medium ${
              selectedStatus === 'Active' 
                ? 'border-green-600 text-green-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Active
          </button>
          <button 
            onClick={() => setSelectedStatus('Inactive')}
            className={`pb-3 px-1 border-b-2 transition-colors font-medium ${
              selectedStatus === 'Inactive' 
                ? 'border-green-600 text-green-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Inactive
          </button>
          <button 
            onClick={() => setSelectedStatus('Out of Stock')}
            className={`pb-3 px-1 border-b-2 transition-colors font-medium ${
              selectedStatus === 'Out of Stock' 
                ? 'border-green-600 text-green-600' 
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Out of Stock
          </button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-600">Filters</span>
          </div>
          <select 
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="All">Category : All</option>
            <option value="Men">Men</option>
            <option value="Women">Women</option>
            <option value="Kids">Kids</option>
          </select>
        </div>

        {/* Products Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sl. no.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Posted on</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product code</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sub Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GST</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredProducts.map((product) => (
                <tr key={product.id} className="hover:bg-gray-50">
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{product.id}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{product.date}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{product.code}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{product.category}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{product.subcategory}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{product.product}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{product.price}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{product.gst}</td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(product.status)}`}>
                      {product.status}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <button className="text-gray-400 hover:text-gray-600">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-gray-400 hover:text-gray-600">
                        <Edit className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-2 mt-6">
          <button className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center text-sm font-medium">1</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">2</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">3</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">4</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">5</button>
          <span className="text-gray-400 px-2">...</span>
        </div>
      </div>
    </div>
  );
}
