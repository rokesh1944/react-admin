
import { useState } from 'react';
import { Search, Bell, User, Plus, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

const advertisementData = [
  {
    id: 1,
    productNo: '01',
    category: 'Mens',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=200&h=200&fit=crop',
    title: 'Relaxed Fit Hoodie'
  },
  {
    id: 2,
    productNo: '02',
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=200&h=200&fit=crop',
    title: 'Casual Wear'
  },
  {
    id: 3,
    productNo: '03',
    category: 'Kids',
    image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=200&h=200&fit=crop',
    title: 'Kids Fashion'
  },
  {
    id: 4,
    productNo: '04',
    category: 'Others',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=200&h=200&fit=crop',
    title: 'Accessories'
  }
];

export function Advertisement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [selectedAd, setSelectedAd] = useState(null);
  const [formData, setFormData] = useState({
    productNo: '01',
    category: 'Mens',
    heading: 'Relaxed Fit Hoodie',
    content: 'Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing Elit. Sit Cras Duis Ac Fermentum At Urna, Dictumst Ultrices Tortor. Adipiscing Sed Urna, Neque Posuere Aliquam Porttitor At.'
  });

  const filteredAds = advertisementData.filter(ad =>
    ad.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ad.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ad.productNo.includes(searchTerm)
  );

  const handleEdit = (ad) => {
    setSelectedAd(ad);
    setFormData({
      productNo: ad.productNo,
      category: ad.category,
      heading: ad.title,
      content: 'Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing Elit. Sit Cras Duis Ac Fermentum At Urna, Dictumst Ultrices Tortor. Adipiscing Sed Urna, Neque Posuere Aliquam Porttitor At.'
    });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    console.log('Delete advertisement:', id);
  };

  const handleUpload = () => {
    console.log('Upload advertisement:', formData);
    setShowForm(false);
    setSelectedAd(null);
  };

  const handleDiscard = () => {
    setShowForm(false);
    setSelectedAd(null);
    setFormData({
      productNo: '01',
      category: 'Mens',
      heading: 'Relaxed Fit Hoodie',
      content: 'Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing Elit. Sit Cras Duis Ac Fermentum At Urna, Dictumst Ultrices Tortor. Adipiscing Sed Urna, Neque Posuere Aliquam Porttitor At.'
    });
  };

  if (showForm) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-4">
            <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <User className="h-4 w-4 text-gray-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Joseph</p>
                <p className="text-xs text-gray-500">Admin</p>
              </div>
            </div>
          </div>
        </div>

        {/* Advertisement Form */}
        <Card className="p-8">
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="productNo" className="text-sm font-medium text-gray-700">
                  Product No. : {formData.productNo}
                </Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="images" className="text-sm font-medium text-gray-700">
                  Product Images
                </Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Button variant="outline" className="text-green-600 border-green-600 hover:bg-green-50">
                    Upload Image
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category" className="text-sm font-medium text-gray-700">
                Product Category
              </Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mens">Mens</SelectItem>
                  <SelectItem value="Women">Women</SelectItem>
                  <SelectItem value="Kids">Kids</SelectItem>
                  <SelectItem value="Others">Others</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="heading" className="text-sm font-medium text-gray-700">
                Heading
              </Label>
              <Input
                id="heading"
                value={formData.heading}
                onChange={(e) => setFormData({...formData, heading: e.target.value})}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content" className="text-sm font-medium text-gray-700">
                Content
              </Label>
              <Textarea
                id="content"
                value={formData.content}
                onChange={(e) => setFormData({...formData, content: e.target.value})}
                className="w-full min-h-[120px] resize-none"
                rows={5}
              />
            </div>

            <div className="flex justify-end gap-4 pt-4">
              <Button 
                variant="outline" 
                onClick={handleDiscard}
                className="px-8 py-2 text-red-600 border-red-300 hover:bg-red-50"
              >
                Discard
              </Button>
              <Button 
                onClick={handleUpload}
                className="px-8 py-2 bg-green-600 hover:bg-green-700 text-white"
              >
                Upload
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 text-sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Products
          </Button>
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Advertisement Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredAds.map((ad) => (
          <Card key={ad.id} className="overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Product No. : {ad.productNo}
                </h3>
              </div>
              
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
                  <img 
                    src={ad.image} 
                    alt={ad.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Product Category</p>
                  <p className="font-medium text-gray-900">{ad.category}</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(ad.id)}
                  className="text-red-500 hover:text-red-700 hover:bg-red-50 px-3"
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEdit(ad)}
                  className="text-gray-600 hover:text-gray-800 hover:bg-gray-100 px-3"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredAds.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500">No advertisements found matching your search.</p>
        </div>
      )}
    </div>
  );
}
