
import { Search, Bell, User } from 'lucide-react';
import { StatsCard } from './dashboard/StatsCard';
import { SalesGraph } from './dashboard/SalesGraph';
import { RevenueChart } from './dashboard/RevenueChart';
import { OrdersTable } from './dashboard/OrdersTable';
import { LowStockTable } from './dashboard/LowStockTable';
import { ExpenseTable } from './dashboard/ExpenseTable';

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          title="500" 
          subtitle="New" 
          icon="package" 
          bgColor="bg-blue-50" 
          iconColor="text-blue-600" 
        />
        <StatsCard 
          title="660" 
          subtitle="Orders" 
          icon="shopping-cart" 
          bgColor="bg-orange-50" 
          iconColor="text-orange-600" 
        />
        <StatsCard 
          title="400" 
          subtitle="Delivered" 
          icon="truck" 
          bgColor="bg-purple-50" 
          iconColor="text-purple-600" 
        />
        <StatsCard 
          title="250" 
          subtitle="Revenue" 
          icon="dollar-sign" 
          bgColor="bg-green-50" 
          iconColor="text-green-600" 
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SalesGraph />
        <RevenueChart />
      </div>

      {/* Tables Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <OrdersTable />
          <ExpenseTable />
        </div>
        <LowStockTable />
      </div>
    </div>
  );
}
