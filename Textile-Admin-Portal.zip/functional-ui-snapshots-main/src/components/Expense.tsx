
import { useState } from 'react';
import { Search, Bell, User, Plus, Calendar } from 'lucide-react';
import { ExpenseForm } from './expense/ExpenseForm';

const expenseData = [
  { sl: '01', date: '15/11/2023', category: 'Electricity', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 13,000', status: 'Paid' },
  { sl: '02', date: '15/11/2023', category: 'Internet', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 1,500', status: 'Paid' },
  { sl: '03', date: '15/11/2023', category: 'Water', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 800', status: 'Unpaid' },
  { sl: '04', date: '15/11/2023', category: 'Furniture', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 2,000', status: 'Paid' },
  { sl: '05', date: '15/11/2023', category: 'Print', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 50', status: 'Paid' },
  { sl: '06', date: '15/11/2023', category: 'Courier', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 300', status: 'Unpaid' },
  { sl: '07', date: '15/11/2023', category: 'Food', subCategory: 'Lorem ipsum dolor', description: 'Lorem ipsum dolor sit amet ...', amount: '₹ 850', status: 'Paid' }
];

export function Expense() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);

  const filteredExpenses = expenseData.filter(expense =>
    expense.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    expense.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    return status === 'Paid' ? 'text-green-600' : 'text-red-600';
  };

  const totalPaid = expenseData.filter(e => e.status === 'Paid').reduce((sum, e) => sum + parseInt(e.amount.replace(/[^\d]/g, '')), 0);
  const totalUnpaid = expenseData.filter(e => e.status === 'Unpaid').reduce((sum, e) => sum + parseInt(e.amount.replace(/[^\d]/g, '')), 0);
  const totalAmount = totalPaid + totalUnpaid;

  if (showForm) {
    return <ExpenseForm onClose={() => setShowForm(false)} />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Expense Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Expense</h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>Date:</span>
              <span>15/11/2023</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>From:</span>
              <span>11/11/2023</span>
              <Calendar className="h-4 w-4" />
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>To:</span>
              <span>15/11/2023</span>
              <Calendar className="h-4 w-4" />
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
            <button 
              onClick={() => setShowForm(true)}
              className="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2 hover:bg-green-700 transition-colors"
            >
              <Plus className="h-4 w-4" />
              Add Expense
            </button>
          </div>
        </div>

        {/* Expense Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sl. no.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sub Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredExpenses.map((expense) => (
                <tr key={expense.sl} className="hover:bg-gray-50">
                  <td className="px-4 py-4 text-sm text-gray-900">{expense.sl}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{expense.date}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{expense.category}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{expense.subCategory}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{expense.description}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{expense.amount}</td>
                  <td className="px-4 py-4 text-sm">
                    <span className={getStatusColor(expense.status)}>{expense.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Summary */}
        <div className="mt-8 flex justify-center gap-8 text-lg font-medium">
          <div className="text-orange-600">
            Paid Amount: ₹{totalPaid.toLocaleString()}
          </div>
          <div className="text-red-600">
            Unpaid Amount: ₹{totalUnpaid.toLocaleString()}
          </div>
          <div className="text-green-600">
            Total Amount: ₹{totalAmount.toLocaleString()}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex justify-end gap-4">
          <button className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
            Print
          </button>
          <button className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
