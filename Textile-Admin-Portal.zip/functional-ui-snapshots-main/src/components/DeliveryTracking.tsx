
import { useState } from 'react';
import { Search, Bell, User, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

const deliveryData = [
  { sl: '01', date: '07/12/2023', invoiceNumber: '62786457345', name: 'Ramesh', location: 'Coimbatore', contact: '99999 88888', products: 2, price: 'Rs. 100', trackingId: 'Enter Track Id' },
  { sl: '02', date: '07/12/2023', invoiceNumber: '62786457346', name: 'Gokul', location: 'Madurai', contact: '99999 88888', products: 4, price: 'Rs. 300', trackingId: 'Enter Track Id' },
  { sl: '03', date: '07/12/2023', invoiceNumber: '62786457347', name: 'Ajith', location: 'Chennai', contact: '99999 88888', products: 1, price: 'Rs. 150', trackingId: 'Enter Track Id' },
  { sl: '04', date: '07/12/2023', invoiceNumber: '62786457348', name: 'Anil', location: 'Trichy', contact: '99999 88888', products: 4, price: 'Rs. 400', trackingId: 'Enter Track Id' },
  { sl: '05', date: '07/12/2023', invoiceNumber: '62786457349', name: 'Sheela', location: 'Nagercoil', contact: '99999 88888', products: 3, price: 'Rs. 300', trackingId: 'Enter Track Id' },
  { sl: '06', date: '07/12/2023', invoiceNumber: '62786457350', name: 'Abish', location: 'Thenkasi', contact: '99999 88888', products: 2, price: 'Rs. 200', trackingId: 'Enter Track Id' },
  { sl: '07', date: '07/12/2023', invoiceNumber: '62786457351', name: 'Akash', location: 'Tirunagar', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '08', date: '07/12/2023', invoiceNumber: '62786457352', name: 'Naveen', location: 'Erode', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '09', date: '07/12/2023', invoiceNumber: '62786457353', name: 'Mani', location: 'Chennai', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '10', date: '07/12/2023', invoiceNumber: '62786457354', name: 'Suresh', location: 'Madurai', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '11', date: '07/12/2023', invoiceNumber: '62786457355', name: 'Abhishek', location: 'Coimbatore', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '12', date: '07/12/2023', invoiceNumber: '62786457356', name: 'Adi', location: 'Nagercoil', contact: '99999 88888', products: 2, price: 'Rs. 200', trackingId: 'BLR515063421' },
  { sl: '13', date: '07/12/2023', invoiceNumber: '62786457357', name: 'Vijay', location: 'Salem', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '14', date: '07/12/2023', invoiceNumber: '62786457358', name: 'Ajith', location: 'Salem', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' },
  { sl: '15', date: '07/12/2023', invoiceNumber: '62786457359', name: 'Suriya', location: 'Salem', contact: '99999 88888', products: 1, price: 'Rs. 100', trackingId: 'BLR515063421' }
];

export function DeliveryTracking() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showTrackingForm, setShowTrackingForm] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const filteredData = deliveryData.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.invoiceNumber.includes(searchTerm)
  );

  const handleTrackClick = (order: any) => {
    setSelectedOrder(order);
    setShowTrackingForm(true);
  };

  if (showTrackingForm && selectedOrder) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-4">
            <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <User className="h-4 w-4 text-gray-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Joseph</p>
                <p className="text-xs text-gray-500">Admin</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tracking Form */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Invoice Number: {selectedOrder.invoiceNumber}</label>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Customer Name: {selectedOrder.name}</label>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Track Number</label>
              <input
                type="text"
                defaultValue="BLR515063421"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Partner</label>
              <input
                type="text"
                defaultValue="Professional Couriers"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Track link</label>
            <input
              type="text"
              defaultValue="https://trackcourier.io/track-and-trace-professi-..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>

          <div className="flex justify-end gap-4">
            <button 
              onClick={() => setShowTrackingForm(false)}
              className="px-6 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              Discard
            </button>
            <button className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
              Save
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Delivery Tracking Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Delivery Tracking</h2>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">Today</span>
            <Calendar className="h-4 w-4 text-gray-400" />
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </div>

        {/* Delivery Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sl. no.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Invoice number</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contact Number</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Products</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tracking ID</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((item) => (
                <tr key={item.sl} className="hover:bg-gray-50">
                  <td className="px-4 py-4 text-sm text-gray-900">{item.sl}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{item.date}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{item.invoiceNumber}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{item.name}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{item.location}</td>
                  <td className="px-4 py-4 text-sm text-gray-600">{item.contact}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{item.products}</td>
                  <td className="px-4 py-4 text-sm text-gray-900">{item.price}</td>
                  <td className="px-4 py-4 text-sm">
                    {item.trackingId === 'Enter Track Id' ? (
                      <button 
                        onClick={() => handleTrackClick(item)}
                        className="text-blue-600 hover:text-blue-800 underline"
                      >
                        {item.trackingId}
                      </button>
                    ) : (
                      <span className="text-gray-900">{item.trackingId}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-2 mt-6">
          <button className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center text-sm font-medium">1</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">2</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">3</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">4</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">5</button>
          <span className="text-gray-400 px-2">...</span>
          <ChevronRight className="h-4 w-4 text-gray-400" />
        </div>
      </div>
    </div>
  );
}
