import { useState } from 'react';
import { Search, Bell, User, Filter, Calendar } from 'lucide-react';
import { OrderDetails } from './orders/OrderDetails';
import { InvoiceView } from './orders/InvoiceView';

const orders = [
  { id: '01', date: '07/12/2023', name: 'Ramesh', location: 'Coimbatore', contact: '99999 88888', category: 'Men', subcategory: 'T-Shirt', products: 'Printed', quantity: 1, price: 'Rs. 100', status: 'Total Price: Rs. 200' },
  { id: '02', date: '07/12/2023', name: 'Gokul', location: 'Madurai', contact: '99999 88888', category: 'Women', subcategory: 'Saree', products: 'Cotton Saree', quantity: 2, price: 'Rs. 200', status: 'Dispatched' },
  { id: '03', date: '07/12/2023', name: 'Ajith', location: 'Chennai', contact: '99999 88888', category: 'Men', subcategory: 'Shirt', products: 'Casual Shirt', quantity: 1, price: 'Rs. 150', status: 'Dispatched' },
  { id: '04', date: '07/12/2023', name: 'Anil', location: 'Trichy', contact: '99999 88888', category: 'Kids', subcategory: 'Shorts', products: 'Shorts', quantity: 4, price: 'Rs. 400', status: 'Dispatched' },
  { id: '05', date: '07/12/2023', name: 'Sheela', location: 'Nagercoil', contact: '99999 88888', category: 'Men', subcategory: 'Shorts', products: 'Sports Shorts', quantity: 3, price: 'Rs. 300', status: 'Dispatched' },
  { id: '06', date: '07/12/2023', name: 'Abish', location: 'Thenkasi', contact: '99999 88888', category: 'Women', subcategory: 'Saree', products: 'Cotton Saree', quantity: 2, price: 'Rs. 200', status: 'Dispatched' },
  { id: '07', date: '07/12/2023', name: 'Akash', location: 'Tirunagar', contact: '99999 88888', category: 'Men', subcategory: 'Vest', products: 'Vest', quantity: 1, price: 'Rs. 100', status: 'Dispatched' },
  { id: '08', date: '07/12/2023', name: 'Naveen', location: 'Erode', contact: '99999 88888', category: 'Women', subcategory: 'Kurth', products: 'V Neck', quantity: 1, price: 'Rs. 100', status: 'Cancelled' },
  { id: '09', date: '07/12/2023', name: 'Mani', location: 'Chennai', contact: '99999 88888', category: 'Men', subcategory: 'Pant', products: 'Slim fit', quantity: 1, price: 'Rs. 100', status: 'Dispatched' },
  { id: '10', date: '07/12/2023', name: 'Suresh', location: 'Madurai', contact: '99999 88888', category: 'Men', subcategory: 'Shirt', products: 'Casual', quantity: 1, price: 'Rs. 100', status: 'Dispatched' },
  { id: '11', date: '07/12/2023', name: 'Abhishek', location: 'Coimbatore', contact: '99999 88888', category: 'Men', subcategory: 'Shirt', products: 'Formal', quantity: 1, price: 'Rs. 100', status: 'Dispatched' },
  { id: '12', date: '07/12/2023', name: 'Adi', location: 'Nagercoil', contact: '99999 88888', category: 'Kids', subcategory: 'Shorts', products: 'Shorts', quantity: 2, price: 'Rs. 200', status: 'Dispatched' },
  { id: '13', date: '07/12/2023', name: 'Vijay', location: 'Salem', contact: '99999 88888', category: 'Kids', subcategory: 'T-Shirts', products: 'Round neck', quantity: 3, price: 'Rs. 300', status: 'Cancelled' },
];

export function Orders() {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [productFilter, setProductFilter] = useState('All');
  const [currentView, setCurrentView] = useState('orders'); // 'orders', 'details', 'invoice'
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const filteredOrders = orders.filter(order => 
    (order.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
     order.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
     order.products.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (categoryFilter === 'All' || order.category === categoryFilter) &&
    (productFilter === 'All' || order.subcategory === productFilter)
  );

  const getStatusColor = (status: string) => {
    if (status.includes('Total Price')) return 'bg-blue-100 text-blue-800';
    if (status === 'Dispatched') return 'bg-green-100 text-green-800';
    if (status === 'Cancelled') return 'bg-red-100 text-red-800';
    return 'bg-gray-100 text-gray-800';
  };

  const handleOrderClick = (orderId: string) => {
    setSelectedOrderId(orderId);
    setCurrentView('details');
  };

  if (currentView === 'details') {
    return <OrderDetails orderId={selectedOrderId} onBack={() => setCurrentView('orders')} />;
  }

  if (currentView === 'invoice') {
    return <InvoiceView />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center gap-4">
          <Bell className="h-5 w-5 text-gray-500 cursor-pointer hover:text-gray-700" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-gray-600" />
            </div>
            <div>
              <p className="text-sm font-medium">Joseph</p>
              <p className="text-xs text-gray-500">Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Orders Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Orders</h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-600">Filters</span>
            </div>
            <select 
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            >
              <option value="All">Category : All</option>
              <option value="Men">Men</option>
              <option value="Women">Women</option>
              <option value="Kids">Kids</option>
            </select>
            <select 
              value={productFilter}
              onChange={(e) => setProductFilter(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            >
              <option value="All">Product : All</option>
              <option value="T-Shirt">T-Shirt</option>
              <option value="Shirt">Shirt</option>
              <option value="Saree">Saree</option>
              <option value="Shorts">Shorts</option>
              <option value="Kurth">Kurth</option>
              <option value="Vest">Vest</option>
              <option value="Pant">Pant</option>
            </select>
            <div className="flex items-center gap-2 border border-gray-300 rounded-md px-3 py-2 bg-white">
              <span className="text-sm text-gray-600">Today</span>
              <Calendar className="h-4 w-4 text-gray-400" />
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sl. no.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact Number</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sub Category</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Products</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Qnt.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td 
                    className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 cursor-pointer hover:text-blue-600"
                    onClick={() => handleOrderClick(order.id)}
                  >
                    {order.id}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{order.date}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.name}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{order.location}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{order.contact}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.category}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">{order.subcategory}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.products}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.quantity}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.price}</td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-2 mt-6">
          <button className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center text-sm font-medium">1</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">2</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">3</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">4</button>
          <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-sm font-medium">5</button>
          <span className="text-gray-400 px-2">•</span>
          <span className="text-gray-400 px-2">•</span>
          <span className="text-gray-400 px-2">•</span>
        </div>
      </div>
    </div>
  );
}
