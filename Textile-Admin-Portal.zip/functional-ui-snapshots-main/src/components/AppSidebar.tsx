
import { 
  LayoutDashboard, 
  Upload, 
  ShoppingCart, 
  Truck, 
  Package, 
  DollarSign, 
  Star, 
  Megaphone, 
  LogOut 
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

const menuItems = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    key: "dashboard",
  },
  {
    title: "Upload Products",
    icon: Upload,
    key: "upload-products",
  },
  {
    title: "Orders",
    icon: ShoppingCart,
    key: "orders",
  },
  {
    title: "Delivery Tracking",
    icon: Truck,
    key: "delivery-tracking",
  },
  {
    title: "Stocks",
    icon: Package,
    key: "stocks",
  },
  {
    title: "Expense",
    icon: DollarSign,
    key: "expense",
  },
  {
    title: "Reviews & Ratings",
    icon: Star,
    key: "reviews-ratings",
  },
  {
    title: "Advertisement",
    icon: Megaphone,
    key: "advertisement",
  },
];

interface AppSidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export function AppSidebar({ activeSection, setActiveSection }: AppSidebarProps) {
  return (
    <Sidebar className="border-r border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-xl font-bold text-gray-800">.cloths</h1>
      </div>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.key}>
                  <SidebarMenuButton 
                    onClick={() => setActiveSection(item.key)}
                    className={`w-full justify-start gap-3 px-4 py-3 hover:bg-gray-100 transition-colors ${
                      activeSection === item.key ? 'bg-gray-100 text-green-600 border-r-2 border-green-600' : 'text-gray-600'
                    }`}
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <div className="mt-auto p-4 border-t border-gray-200">
          <SidebarMenuButton className="w-full justify-start gap-3 px-4 py-3 text-gray-600 hover:bg-gray-100 transition-colors">
            <LogOut className="h-4 w-4" />
            <span>Log Out</span>
          </SidebarMenuButton>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
