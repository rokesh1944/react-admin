
import { useState } from 'react';
import { ArrowLeft, Upload, Plus } from 'lucide-react';

interface ProductFormProps {
  onClose: () => void;
}

export function ProductForm({ onClose }: ProductFormProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    code: '254',
    category: 'Mens',
    subcategory: 'Shirt',
    name: 'Plain Shirt',
    type: 'Western Wear',
    price: '1,000',
    gst: '10%',
    colors: ['#8B1538', '#800000'],
    sizes: ['S', 'M', 'L', 'XL'],
    quantities: { S: '10', M: '10', L: '10', XL: '10' },
    status: 'Active'
  });

  const colorOptions = [
    '#8B1538', '#800000', '#000080', '#008000', '#FF0000', '#FFA500',
    '#FFFF00', '#008080', '#800080', '#FFC0CB', '#A52A2A', '#808080'
  ];

  const handleContinue = () => {
    if (step === 1) {
      setStep(2);
    } else {
      // Handle form submission
      console.log('Form submitted:', formData);
      onClose();
    }
  };

  const handleBack = () => {
    if (step === 2) {
      setStep(1);
    } else {
      onClose();
    }
  };

  if (step === 2) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <button 
            onClick={handleBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>
          <h2 className="text-xl font-semibold text-gray-900">New Product</h2>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="space-y-6">
            {/* Product Summary */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-gray-600">Product code</p>
                <p className="font-medium">{formData.code}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Product Category</p>
                <p className="font-medium">{formData.category}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Sub Category</p>
                <p className="font-medium">{formData.subcategory}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Product Name</p>
                <p className="font-medium">{formData.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Product Type</p>
                <p className="font-medium">{formData.type}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Price</p>
                <p className="font-medium">Rs {formData.price}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">GST</p>
                <p className="font-medium">{formData.gst}</p>
              </div>
            </div>

            {/* Colors */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Colours</p>
              <div className="flex gap-2">
                {formData.colors.map((color, index) => (
                  <div
                    key={index}
                    className="w-6 h-6 rounded border border-gray-300"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {/* Sizes */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Sizes</p>
              <p className="font-medium">{formData.sizes.join(', ')}</p>
            </div>

            {/* Product Images */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Photos</p>
              <div className="flex gap-2">
                {/* Mock product images */}
                <div className="w-16 h-16 bg-gray-200 rounded border flex items-center justify-center">
                  <div className="w-12 h-12 bg-red-800 rounded"></div>
                </div>
                <div className="w-16 h-16 bg-gray-200 rounded border flex items-center justify-center">
                  <div className="w-12 h-12 bg-red-600 rounded"></div>
                </div>
                <div className="w-16 h-16 bg-gray-200 rounded border flex items-center justify-center">
                  <div className="w-12 h-12 bg-blue-600 rounded"></div>
                </div>
                <div className="w-16 h-16 bg-gray-200 rounded border flex items-center justify-center">
                  <div className="w-12 h-12 bg-blue-800 rounded"></div>
                </div>
              </div>
            </div>

            {/* Status */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Status</p>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input type="radio" name="status" value="Active" defaultChecked className="text-green-600" />
                  <span>Active</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="status" value="Inactive" className="text-red-600" />
                  <span>Inactive</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="status" value="Out of Stock" className="text-orange-600" />
                  <span>Out of Stock</span>
                </label>
              </div>
            </div>

            {/* Action Button */}
            <div className="flex justify-end">
              <button 
                onClick={handleContinue}
                className="px-8 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={handleBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </button>
        <h2 className="text-xl font-semibold text-gray-900">New Product</h2>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Product Code</label>
              <input
                type="text"
                value={formData.code}
                onChange={(e) => setFormData({...formData, code: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Sub Category</label>
              <input
                type="text"
                value={formData.subcategory}
                onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Product Type</label>
              <select 
                value={formData.type}
                onChange={(e) => setFormData({...formData, type: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option>Western Wear</option>
                <option>Traditional Wear</option>
                <option>Casual Wear</option>
              </select>
              <button className="text-sm text-green-600 hover:text-green-700 mt-1">Add New Product Type</button>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">GST</label>
              <input
                type="text"
                value={formData.gst}
                onChange={(e) => setFormData({...formData, gst: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Product Category</label>
              <select 
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option>Mens</option>
                <option>Womens</option>
                <option>Kids</option>
              </select>
              <button className="text-sm text-green-600 hover:text-green-700 mt-1">Add New Category</button>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Product name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Price</label>
              <input
                type="text"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </div>

        {/* Available Colours, Sizes & Quantity Section */}
        <div className="mt-8">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Available Colours, Sizes & Quantity</h3>
          
          {/* Colors */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">Colour</label>
              <button className="text-sm text-green-600 hover:text-green-700">Change in Numbers</button>
            </div>
            <div className="grid grid-cols-6 gap-2 mb-2">
              {colorOptions.map((color, index) => (
                <button
                  key={index}
                  className={`w-10 h-10 rounded border-2 ${
                    formData.colors.includes(color) ? 'border-gray-600 ring-2 ring-gray-300' : 'border-gray-200'
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => {
                    const newColors = formData.colors.includes(color)
                      ? formData.colors.filter(c => c !== color)
                      : [...formData.colors, color];
                    setFormData({...formData, colors: newColors});
                  }}
                />
              ))}
            </div>
            <button className="text-sm text-green-600 hover:text-green-700 flex items-center gap-1">
              <Plus className="h-4 w-4" />
              Add More
            </button>
          </div>

          {/* Size and Quantity */}
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Size</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                <option>S</option>
                <option>M</option>
                <option>L</option>
                <option>XL</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
              <input
                type="text"
                defaultValue="10"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>

          {/* Second row */}
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                <option>M</option>
                <option>S</option>
                <option>L</option>
                <option>XL</option>
              </select>
            </div>
            <div>
              <input
                type="text"
                defaultValue="10"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>

          {/* Upload Images */}
          <div className="mb-6">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-1">Drop your images here, or <span className="text-green-600 cursor-pointer">browse</span></p>
              <p className="text-sm text-gray-400">Supports: JPG, JPEG, PNG</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-4">
            <button 
              onClick={onClose}
              className="px-6 py-2 text-red-600 border border-red-600 rounded-lg hover:bg-red-50 transition-colors"
            >
              Discard
            </button>
            <button 
              onClick={handleContinue}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
