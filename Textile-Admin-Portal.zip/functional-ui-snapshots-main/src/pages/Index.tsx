
import { useState } from 'react';
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from '@/components/AppSidebar';
import { Dashboard } from '@/components/Dashboard';
import { UploadProducts } from '@/components/UploadProducts';
import { Orders } from '@/components/Orders';
import { DeliveryTracking } from '@/components/DeliveryTracking';
import { Stocks } from '@/components/Stocks';
import { Expense } from '@/components/Expense';
import { ReviewsRatings } from '@/components/ReviewsRatings';
import { Advertisement } from '@/components/Advertisement';

const Index = () => {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'upload-products':
        return <UploadProducts />;
      case 'orders':
        return <Orders />;
      case 'delivery-tracking':
        return <DeliveryTracking />;
      case 'stocks':
        return <Stocks />;
      case 'expense':
        return <Expense />;
      case 'reviews-ratings':
        return <ReviewsRatings />;
      case 'advertisement':
        return <Advertisement />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50">
        <AppSidebar activeSection={activeSection} setActiveSection={setActiveSection} />
        <main className="flex-1 p-6">
          {renderContent()}
        </main>
      </div>
    </SidebarProvider>
  );
};

export default Index;
